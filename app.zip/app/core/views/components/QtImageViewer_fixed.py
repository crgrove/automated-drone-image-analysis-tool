"""
QtImageViewer.py - QGraphicsView-based image viewer with zoom / pan / ROI.

This version (2.1.1 fixed) includes fixes for viewer lockup issues:
- Prevents infinite recursion in zoom operations
- Adds safeguards against degenerate zoom rectangles
- Improves floating point precision handling
- Adds maximum zoom stack depth limit
"""

import os.path
from PyQt5.QtCore import (
    Qt, QRectF, QPoint, QPointF, pyqtSignal, QEvent, QSize
)
from PyQt5.QtGui import (
    QImage, QPixmap, QPainterPath, QMouseEvent, QPainter, QPen, QCursor
)
from PyQt5.QtWidgets import (
    QGraphicsView, QGraphicsScene, QFileDialog, QSizePolicy,
    QGraphicsItem, QGraphicsEllipseItem, QGraphicsRectItem,
    QGraphicsLineItem, QGraphicsPolygonItem
)

# Optional deps
try:
    import numpy as np
except ImportError:
    np = None
try:
    import qimage2ndarray
except ImportError:
    qimage2ndarray = None

__author__ = "Marcel Goldschen-Ohm <marcel.goldschen@gmail.com>"
__version__ = "2.1.1 (fixed-lockup)"

# Constants for zoom limits
MIN_ZOOM_RECT_SIZE = 10.0  # Minimum size in pixels to prevent degenerate rectangles
MAX_ZOOM_STACK_DEPTH = 50  # Maximum zoom stack depth to prevent memory issues
MIN_ZOOM_FACTOR = 0.01  # Minimum zoom factor (1% of original)
MAX_ZOOM_FACTOR = 100.0  # Maximum zoom factor (100x original)

class QtImageViewer(QGraphicsView):
    # -------------------------- public signals --------------------------- #
    leftMouseButtonPressed = pyqtSignal(float, float, object)
    leftMouseButtonReleased = pyqtSignal(float, float)
    middleMouseButtonPressed = pyqtSignal(float, float)
    middleMouseButtonReleased = pyqtSignal(float, float)
    rightMouseButtonPressed = pyqtSignal(float, float)
    rightMouseButtonReleased = pyqtSignal(float, float)
    leftMouseButtonDoubleClicked = pyqtSignal(float, float)
    rightMouseButtonDoubleClicked = pyqtSignal(float, float)

    viewChanged = pyqtSignal()          # any pan / zoom
    zoomChanged = pyqtSignal(float)     # **every** zoom change
    mousePositionOnImageChanged = pyqtSignal(QPoint)
    roiSelected = pyqtSignal(int)

    # ------------------------------ init --------------------------------- #
    def __init__(self, window, parent=None, center=None, thumbnail=False):
        super().__init__(parent)

        # ---- external reference (lets parent window hijack keyPressEvents)
        self.window = window

        # ---- scene / image
        self.scene = QGraphicsScene(self)
        self.setScene(self.scene)
        self._image = None               # QGraphicsPixmapItem
        self._zoom = 1.0                # current view-to-scene scale
        self._recursion_guard = False   # Prevent infinite recursion

        # ---- interaction state
        self.zoomStack = []          # list[QRectF] – manual zoom rectangles
        self._isZooming = False
        self._isPanning = False
        self._pixelPosition = QPoint()
        self._scenePosition = QPointF()

        # ---- config
        self.aspectRatioMode = Qt.KeepAspectRatio
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        self.regionZoomButton = Qt.LeftButton
        self.zoomOutButton = None
        self.panButton = Qt.RightButton
        self.wheelZoomFactor = 1.25

        self.canZoom = True
        self.canPan = True

        self.setMouseTracking(True)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        # ---- misc
        self.center = center
        self.thumbnail = thumbnail

    def keyPressEvent(self, ev):
        plus_keys = {Qt.Key_Plus, Qt.Key_Equal}
        minus_keys = {Qt.Key_Minus, Qt.Key_Underscore}

        # ---------------- zoom-IN ----------------
        if ev.key() in plus_keys and not self.thumbnail:
            vp_pos = self.mapFromGlobal(QCursor.pos())
            scene_pos = (self.mapToScene(vp_pos)
                         if self.viewport().rect().contains(vp_pos)
                         else self.sceneRect().center())
            self._zoomInAtPos(scene_pos)
            ev.accept()
            return

        # ---------------- zoom-OUT ---------------
        if ev.key() in minus_keys and not self.thumbnail:
            vp_pos = self.mapFromGlobal(QCursor.pos())
            scene_pos = (self.mapToScene(vp_pos)
                         if self.viewport().rect().contains(vp_pos)
                         else self.sceneRect().center())
            self._zoomOutAtPos(scene_pos)
            ev.accept()
            return

        # --------- fall back to original handling
        if self.window is not None:
            self.window.keyPressEvent(ev)
        else:
            super().keyPressEvent(ev)

    # ===================================================================== #
    #  Helpers                                                               #
    # ===================================================================== #

    def _emit_zoom_if_changed(self):
        """
        Re-calculate effective zoom from the view's transform matrix and
        emit zoomChanged(float) only if the value really changed.
        """
        new_zoom = self.transform().m11()        # isotropic, so x==y
        if abs(new_zoom - self._zoom) > 1e-6:
            self._zoom = new_zoom
            self.zoomChanged.emit(self._zoom)

    def getZoom(self) -> float:
        """Current zoom factor (1.0 == image fits view in X)."""
        return self._zoom

    def _validate_zoom_rect(self, rect):
        """Validate and sanitize a zoom rectangle."""
        if not rect or not rect.isValid():
            return None
            
        # Ensure minimum size
        if rect.width() < MIN_ZOOM_RECT_SIZE or rect.height() < MIN_ZOOM_RECT_SIZE:
            return None
            
        # Ensure it's within scene bounds
        scene_rect = self.sceneRect()
        if not scene_rect.isValid():
            return None
            
        # Intersect with scene
        rect = rect.intersected(scene_rect)
        
        # Check if intersection is still valid
        if not rect.isValid() or rect.width() < MIN_ZOOM_RECT_SIZE or rect.height() < MIN_ZOOM_RECT_SIZE:
            return None
            
        return rect

    def _cleanup_zoom_stack(self):
        """Clean up zoom stack by removing invalid entries."""
        if not self.zoomStack:
            return
            
        # Remove invalid rectangles
        self.zoomStack = [r for r in self.zoomStack if self._validate_zoom_rect(r)]
        
        # Limit stack depth
        if len(self.zoomStack) > MAX_ZOOM_STACK_DEPTH:
            # Keep only the most recent entries
            self.zoomStack = self.zoomStack[-MAX_ZOOM_STACK_DEPTH:]

    # ===================================================================== #
    #  Image handling                                                        #
    # ===================================================================== #
    def hasImage(self):
        return self._image is not None

    def clearImage(self):
        if self._image:
            self.scene.removeItem(self._image)
            self._image = None

    def pixmap(self):
        return self._image.pixmap() if self._image else None

    def image(self):
        return self._image.pixmap().toImage() if self._image else None

    def setImage(self, img):
        if isinstance(img, QPixmap):
            pixmap = img
        elif isinstance(img, QImage):
            pixmap = QPixmap.fromImage(img)
        elif np and isinstance(img, np.ndarray):
            if qimage2ndarray:
                qimage = qimage2ndarray.array2qimage(img, normalize=False)
                pixmap = QPixmap.fromImage(qimage)
            else:
                raise RuntimeError("qimage2ndarray is required for np.ndarray images")
        else:
            raise RuntimeError(f"Unsupported image type: {type(img)}")

        self.clearImage()
        self._image = self.scene.addPixmap(pixmap)
        self.setSceneRect(QRectF(pixmap.rect()))
        self.resetZoom()

    def loadImageFromFile(self, fileName=""):
        if not fileName:
            fileName, _ = QFileDialog.getOpenFileName(self, "Open image file.")
        if fileName and os.path.isfile(fileName):
            img = QImage(fileName)
            self.setImage(img)

    # ===================================================================== #
    #  Core viewer logic                                                     #
    # ===================================================================== #
    def updateViewer(self):
        """Apply current zoom stack or fit whole image, then emit zoom."""
        if not self.hasImage() or self._recursion_guard:
            return
            
        try:
            self._recursion_guard = True
            
            # Clean up zoom stack first
            self._cleanup_zoom_stack()
            
            if self.zoomStack:
                last_rect = self.zoomStack[-1]
                if self._validate_zoom_rect(last_rect):
                    self.fitInView(last_rect, self.aspectRatioMode)
                else:
                    # Invalid rect, reset zoom
                    self.zoomStack.clear()
                    self.fitInView(self.sceneRect(), self.aspectRatioMode)
            else:
                if self.thumbnail:
                    self.fitInView(self.sceneRect(), self.aspectRatioMode)

            self._emit_zoom_if_changed()
            
        finally:
            self._recursion_guard = False

    # --------------------- programmatic zoom helpers --------------------- #
    def setZoom(self, scale: float):
        """Zoom around the image centre to *scale*."""
        if not self.canZoom or self.thumbnail or not self.hasImage():
            return
            
        # Clamp scale to reasonable limits
        scale = max(MIN_ZOOM_FACTOR, min(MAX_ZOOM_FACTOR, scale))

        sr = self.sceneRect()
        factor = 1.0 / scale
        w = sr.width() * factor
        h = sr.height() * factor
        
        # Check minimum size
        if w < MIN_ZOOM_RECT_SIZE or h < MIN_ZOOM_RECT_SIZE:
            return
            
        zr = QRectF(sr.center().x() - w/2, sr.center().y() - h/2, w, h)
        
        validated_rect = self._validate_zoom_rect(zr)
        if validated_rect:
            self.zoomStack = [validated_rect]
            self.updateViewer()
            self.viewChanged.emit()

    def zoomToArea(self, rect: QRectF):
        """Zoom to show the specified QRectF area."""
        if not self.canZoom or self.thumbnail or not rect.isValid() or not self.hasImage():
            return
            
        validated_rect = self._validate_zoom_rect(rect)
        if validated_rect:
            self.zoomStack = [validated_rect]
            self.updateViewer()
            self.viewChanged.emit()

    # ------------------------------------------------------------- #
    #  zoom helper: zoom-in while keeping scene_pos centred         #
    # ------------------------------------------------------------- #
    def _zoomInAtPos(self, scene_pos, factor=None):
        """Zoom in so *scene_pos* stays centred on screen."""
        if not self.canZoom or self.thumbnail or not self.hasImage():
            return
        factor = factor or self.wheelZoomFactor or 1.25

        if not self.zoomStack:
            self.zoomStack.append(self.sceneRect())
        elif len(self.zoomStack) > 1:
            self.zoomStack[:] = self.zoomStack[-1:]

        zr = self.zoomStack[-1].copy()  # Make a copy to avoid modifying original
        new_width = zr.width() / factor
        new_height = zr.height() / factor
        
        # Check minimum size
        if new_width < MIN_ZOOM_RECT_SIZE or new_height < MIN_ZOOM_RECT_SIZE:
            return
            
        zr.setWidth(new_width)
        zr.setHeight(new_height)
        zr.moveCenter(scene_pos)
        
        validated_rect = self._validate_zoom_rect(zr)
        if validated_rect:
            self.zoomStack[-1] = validated_rect
            self.updateViewer()
            self.viewChanged.emit()

    # ------------------------------------------------------------- #
    #  zoom helper: zoom-out while keeping scene_pos centred         #
    # ------------------------------------------------------------- #
    def _zoomOutAtPos(self, scene_pos, factor=None):
        """Zoom out so *scene_pos* stays centred on screen."""
        if not self.canZoom or self.thumbnail or not self.hasImage():
            return
        factor = factor or self.wheelZoomFactor or 1.25

        if not self.zoomStack:
            self.resetZoom()
            return

        if len(self.zoomStack) > 1:
            self.zoomStack[:] = self.zoomStack[-1:]

        zr = self.zoomStack[-1].copy()  # Make a copy
        zr.setWidth(zr.width() * factor)
        zr.setHeight(zr.height() * factor)
        zr.moveCenter(scene_pos)
        
        validated_rect = self._validate_zoom_rect(zr)
        
        if not validated_rect or validated_rect.contains(self.sceneRect()):
            # We're back to full view
            self.zoomStack.clear()
        else:
            self.zoomStack[-1] = validated_rect

        self.updateViewer()
        self.viewChanged.emit()

    def resetZoom(self):
        self.clearZoom()
        if self.hasImage():
            self.fitInView(self.sceneRect(), self.aspectRatioMode)
            self._emit_zoom_if_changed()

    def clearZoom(self):
        if self.zoomStack:
            self.zoomStack.clear()
            self.updateViewer()
            self.viewChanged.emit()

    # ===================================================================== #
    #  Qt events that might change zoom                                      #
    # ===================================================================== #
    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        self.updateViewer()

    def showEvent(self, ev):
        super().showEvent(ev)
        self.resetZoom()

    # -------------------------- wheel zoom ------------------------------ #
    def wheelEvent(self, ev):
        if self.thumbnail or self.wheelZoomFactor in (None, 1) or not self.hasImage() or self._recursion_guard:
            return super().wheelEvent(ev)

        try:
            self._recursion_guard = True
            
            zoom_in = ev.angleDelta().y() > 0
            cursor_scene_pos = self.mapToScene(ev.pos())
            factor = self.wheelZoomFactor if zoom_in else 1 / self.wheelZoomFactor

            # Ensure zoom stack is initialized
            if not self.zoomStack:
                self.zoomStack.append(self.sceneRect())

            # Clean up stack first
            self._cleanup_zoom_stack()
            
            if not self.zoomStack:
                self.zoomStack.append(self.sceneRect())
                
            current_zr = self.zoomStack[-1].copy()  # Work with a copy

            # Calculate cursor position ratios
            cursor_ratio_x = (cursor_scene_pos.x() - current_zr.left()) / current_zr.width() if current_zr.width() > 0 else 0.5
            cursor_ratio_y = (cursor_scene_pos.y() - current_zr.top()) / current_zr.height() if current_zr.height() > 0 else 0.5
            
            # Clamp ratios to [0, 1]
            cursor_ratio_x = max(0, min(1, cursor_ratio_x))
            cursor_ratio_y = max(0, min(1, cursor_ratio_y))

            new_width = current_zr.width() / factor
            new_height = current_zr.height() / factor

            # Check size limits
            if zoom_in:
                if new_width < MIN_ZOOM_RECT_SIZE or new_height < MIN_ZOOM_RECT_SIZE:
                    ev.accept()
                    return
            else:
                # Check if we're zooming out too far
                scene_rect = self.sceneRect()
                if new_width > scene_rect.width() * 2 or new_height > scene_rect.height() * 2:
                    self.resetZoom()
                    ev.accept()
                    return

            new_left = cursor_scene_pos.x() - cursor_ratio_x * new_width
            new_top = cursor_scene_pos.y() - cursor_ratio_y * new_height

            new_zr = QRectF(new_left, new_top, new_width, new_height)
            validated_rect = self._validate_zoom_rect(new_zr)

            if not zoom_in and (not validated_rect or validated_rect.contains(self.sceneRect())):
                self.resetZoom()
            elif validated_rect:
                self.zoomStack[-1] = validated_rect
                self.updateViewer()
                self.viewChanged.emit()

            ev.accept()
            
        finally:
            self._recursion_guard = False

    # Mouse event handlers remain the same as original...
    # [Rest of the mouse event handlers continue unchanged]
    
    def mousePressEvent(self, ev):
        dummyMods = Qt.ShiftModifier | Qt.ControlModifier | Qt.AltModifier | Qt.MetaModifier
        if ev.modifiers() & dummyMods:
            super().mousePressEvent(ev)
            ev.accept()
            return

        # ------------- region zoom start
        if (self.regionZoomButton and ev.button() == self.regionZoomButton and self.canZoom):
            self._pixelPosition = ev.pos()
            self.setDragMode(QGraphicsView.RubberBandDrag)
            super().mousePressEvent(ev)
            self._isZooming = True
            ev.accept()
            return

        # ------------- zoom-out click
        if (self.zoomOutButton and ev.button() == self.zoomOutButton and self.canZoom):
            if self.zoomStack:
                self.zoomStack.pop()
                self.updateViewer()
                self.viewChanged.emit()
            ev.accept()
            return

        # ------------- pan start
        if (self.panButton and ev.button() == self.panButton and self.canPan):
            self._pixelPosition = ev.pos()
            self.setDragMode(QGraphicsView.ScrollHandDrag)
            if self.panButton == Qt.LeftButton:
                super().mousePressEvent(ev)
            else:  # fake left-button drag
                self.viewport().setCursor(Qt.ClosedHandCursor)
                fakeMods = Qt.ShiftModifier | Qt.ControlModifier | Qt.AltModifier | Qt.MetaModifier
                fakeEv = QMouseEvent(QEvent.MouseButtonPress, QPointF(ev.pos()),
                                     Qt.LeftButton, ev.buttons(), fakeMods)
                self.mousePressEvent(fakeEv)
            self._scenePosition = self.mapToScene(self.viewport().rect()).boundingRect().topLeft()
            self._isPanning = True
            ev.accept()
            return

        scenePos = self.mapToScene(ev.pos())
        if ev.button() == Qt.LeftButton:
            self.leftMouseButtonPressed.emit(scenePos.x(), scenePos.y(), self)
        elif ev.button() == Qt.MiddleButton:
            self.middleMouseButtonPressed.emit(scenePos.x(), scenePos.y())
        elif ev.button() == Qt.RightButton:
            self.rightMouseButtonPressed.emit(scenePos.x(), scenePos.y())

        super().mousePressEvent(ev)

    def mouseReleaseEvent(self, ev):
        dummyMods = Qt.ShiftModifier | Qt.ControlModifier | Qt.AltModifier | Qt.MetaModifier
        if ev.modifiers() & dummyMods:
            super().mouseReleaseEvent(ev)
            ev.accept()
            return

        # ---- finish region zoom
        if (self.regionZoomButton and ev.button() == self.regionZoomButton and self.canZoom):
            super().mouseReleaseEvent(ev)
            zoomRect = self.scene.selectionArea().boundingRect().intersected(self.sceneRect())
            self.scene.setSelectionArea(QPainterPath())
            self.setDragMode(QGraphicsView.NoDrag)

            # tiny rubber-band → treat as click
            if max(abs(ev.pos().x()-self._pixelPosition.x()),
                   abs(ev.pos().y()-self._pixelPosition.y())) <= 3:
                pass
            else:
                validated_rect = self._validate_zoom_rect(zoomRect)
                if validated_rect and validated_rect != self.sceneRect():
                    self.zoomStack.append(validated_rect)
                    self._cleanup_zoom_stack()
                    self.updateViewer()
                    self.viewChanged.emit()
            self._isZooming = False
            ev.accept()
            return

        # ---- finish panning
        if (self.panButton and ev.button() == self.panButton and self.canPan):
            if self.panButton == Qt.LeftButton:
                super().mouseReleaseEvent(ev)
            else:
                self.viewport().setCursor(Qt.ArrowCursor)
                fakeMods = Qt.ShiftModifier | Qt.ControlModifier | Qt.AltModifier | Qt.MetaModifier
                fakeEv = QMouseEvent(QEvent.MouseButtonRelease, QPointF(ev.pos()),
                                     Qt.LeftButton, ev.buttons(), fakeMods)
                self.mouseReleaseEvent(fakeEv)
            self.setDragMode(QGraphicsView.NoDrag)
            if self.zoomStack:
                currentView = self.mapToScene(self.viewport().rect()).boundingRect()
                delta = currentView.topLeft() - self._scenePosition
                self.zoomStack[-1].translate(delta)
                validated_rect = self._validate_zoom_rect(self.zoomStack[-1])
                if validated_rect:
                    self.zoomStack[-1] = validated_rect
                else:
                    self.zoomStack.pop()
                self._cleanup_zoom_stack()
                self.viewChanged.emit()
            self._isPanning = False
            ev.accept()
            return

        scenePos = self.mapToScene(ev.pos())
        if ev.button() == Qt.LeftButton:
            self.leftMouseButtonReleased.emit(scenePos.x(), scenePos.y())
        elif ev.button() == Qt.MiddleButton:
            self.middleMouseButtonReleased.emit(scenePos.x(), scenePos.y())
        elif ev.button() == Qt.RightButton:
            self.rightMouseButtonReleased.emit(scenePos.x(), scenePos.y())

        super().mouseReleaseEvent(ev)

    def mouseDoubleClickEvent(self, ev):
        if (self.zoomOutButton and ev.button() == self.zoomOutButton and self.canZoom):
            self.resetZoom()
            ev.accept()
            return

        scenePos = self.mapToScene(ev.pos())
        if ev.button() == Qt.LeftButton:
            self.resetZoom()
            self.leftMouseButtonDoubleClicked.emit(scenePos.x(), scenePos.y())
        elif ev.button() == Qt.RightButton:
            self.rightMouseButtonDoubleClicked.emit(scenePos.x(), scenePos.y())

        super().mouseDoubleClickEvent(ev)

    def mouseMoveEvent(self, ev):
        if self._isPanning:
            super().mouseMoveEvent(ev)
            ev.accept()
            return

        if self._isZooming:
            super().mouseMoveEvent(ev)
            ev.accept()
            return

        scenePos = self.mapToScene(ev.pos())
        if self.sceneRect().contains(scenePos):
            pixelPos = QPoint(int(scenePos.x()), int(scenePos.y()))
            if pixelPos != self._pixelPosition:
                self._pixelPosition = pixelPos
                self.mousePositionOnImageChanged.emit(pixelPos)
                
        super().mouseMoveEvent(ev)